function Landing(props) {
    return (
        <div>
            Welcome home
        </div>
    );
}

export default Landing;
