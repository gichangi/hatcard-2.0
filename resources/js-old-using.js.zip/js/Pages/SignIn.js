import Layout from "./Layout";

function Signing(props) {
  return (
      <div>
        <Layout/>
        Signing mew cowssskssssss
      </div>
  );
}
export default Signing;
