
import Progress from './Progress';

const Loader = () => {
  return (
    <>
      <Progress isAnimating />
    </>
  );
};

export default Loader;
