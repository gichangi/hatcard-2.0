
import { CKEditor } from '@ckeditor/ckeditor5-react';

const AllCkEditor = (props) => {
  return <CKEditor {...props} />;
};

export default AllCkEditor;
